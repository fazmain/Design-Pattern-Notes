package FinalExam;

public class CancelOrderCommand implements Command {
    public void execute() {
        System.out.println("Order canceled.");
    }
}
