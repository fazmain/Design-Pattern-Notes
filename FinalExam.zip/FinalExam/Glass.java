package FinalExam;

public interface Glass {
    String getType();
}
