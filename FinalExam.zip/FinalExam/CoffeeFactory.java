package FinalExam;

public interface CoffeeFactory {
    Coffee createCoffee();
}
