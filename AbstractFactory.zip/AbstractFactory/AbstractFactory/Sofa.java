public interface Sofa {
    void sitOn();
}
