package FinalExam;

public class SteelGlass implements Glass {
    public String getType() {
        return "Steel";
    }
}
