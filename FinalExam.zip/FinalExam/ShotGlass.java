package FinalExam;

public class ShotGlass implements Glass {
    public String getType() {
        return "Shot";
    }
}
