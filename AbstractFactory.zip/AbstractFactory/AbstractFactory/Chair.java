public interface Chair {
    void sitOn();
}

