package FinalExam;

public interface GlassFactory {
    Glass createGlass();
}
