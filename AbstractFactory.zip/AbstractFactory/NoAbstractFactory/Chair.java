package NoAbstractFactory;

public interface Chair {
    void sitOn();
}
