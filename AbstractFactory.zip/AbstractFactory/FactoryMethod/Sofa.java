package FactoryMethod;

public interface Sofa {
    void sitOn();
}
