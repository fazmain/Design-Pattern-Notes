package FinalExam;

public interface Command {
    void execute();
}



