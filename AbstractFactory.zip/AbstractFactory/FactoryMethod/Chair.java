package FactoryMethod;

public interface Chair {
    void sitOn();
}
